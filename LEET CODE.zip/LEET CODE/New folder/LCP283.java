public class LCP283 {
    public static void main(String[] args) {
        int[] arr={100,0,1,0,3,12,0,1000};
        int j=0;
        for(int i =0;i<arr.length;i++){
            if(arr[i]!=0){
                int temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
                j++;
            }
            
        }
       for(int i=0;i<arr.length;i++){
         System.out.print(arr[i]+" ");
       }
    }
}
